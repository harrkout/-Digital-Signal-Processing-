b=[4 -7/4 1/4]
a=[1 -3/4 1/8]

[z,  p,  c] = tf2zp(b, a);
zplane(z,p);
