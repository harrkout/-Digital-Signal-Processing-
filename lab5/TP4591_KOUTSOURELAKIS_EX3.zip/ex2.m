b = [0 0 1];
a = [1 -3 2];
[r, p, k] = residuez(b, a)