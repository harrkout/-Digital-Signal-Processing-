b=[1, 2, 1]
a=[1 -3 1]

[z,  p,  c] = tf2zp(b, a);
zplane(z,p);
